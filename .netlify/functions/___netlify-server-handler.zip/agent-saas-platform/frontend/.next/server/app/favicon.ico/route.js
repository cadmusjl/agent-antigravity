var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__59f2c647._.js")
R.c("server/chunks/7acde_frontend__next-internal_server_app_favicon_ico_route_actions_3ad4448b.js")
R.m(68682)
module.exports=R.m(68682).exports
