globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/4eb8e509546dbc7b.js",
    "static/chunks/59f96d4179960481.js",
    "static/chunks/d91a30b0899a9f73.js",
    "static/chunks/07b4f5eaf36672ab.js",
    "static/chunks/turbopack-7176f20741989699.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];