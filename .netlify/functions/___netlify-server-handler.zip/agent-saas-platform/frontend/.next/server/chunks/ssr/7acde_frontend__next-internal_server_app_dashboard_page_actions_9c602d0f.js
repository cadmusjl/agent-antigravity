module.exports=[29969,(a,b,c)=>{}];

//# sourceMappingURL=7acde_frontend__next-internal_server_app_dashboard_page_actions_9c602d0f.js.map