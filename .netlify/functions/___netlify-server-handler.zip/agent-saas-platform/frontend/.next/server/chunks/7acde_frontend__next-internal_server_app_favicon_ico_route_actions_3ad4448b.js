module.exports=[71415,(e,o,d)=>{}];

//# sourceMappingURL=7acde_frontend__next-internal_server_app_favicon_ico_route_actions_3ad4448b.js.map