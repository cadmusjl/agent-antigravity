module.exports=[43423,(a,b,c)=>{}];

//# sourceMappingURL=agent-saas-platform_frontend__next-internal_server_app_page_actions_92904f0b.js.map