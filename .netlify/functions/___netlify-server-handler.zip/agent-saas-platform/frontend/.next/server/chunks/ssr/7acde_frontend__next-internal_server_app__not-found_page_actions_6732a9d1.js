module.exports=[15280,(a,b,c)=>{}];

//# sourceMappingURL=7acde_frontend__next-internal_server_app__not-found_page_actions_6732a9d1.js.map