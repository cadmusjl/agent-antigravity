module.exports=[76747,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},80328,a=>{"use strict";let b={src:a.i(76747).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=agent-saas-platform_frontend_app_b1d6f119._.js.map