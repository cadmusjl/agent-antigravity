module.exports=[71754,(a,b,c)=>{}];

//# sourceMappingURL=7acde_frontend__next-internal_server_app__global-error_page_actions_713c6106.js.map